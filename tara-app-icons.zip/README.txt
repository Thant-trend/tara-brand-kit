TARA APP ICON PACK
==================

svg/       Vector originals. Scale to any size.
png/       Every version at its store sizes, named <version>-<size>.png.
ios/       AppIcon-1024.png: full-bleed square for Xcode and App Store Connect.
           iOS rounds the corners. If App Store Connect rejects the alpha channel,
           flatten the PNG onto the tile colour once.
android/   Adaptive icon layers: foreground, background, monochrome (SVG).
           Import in Android Studio with New > Image Asset > Adaptive icon.
web/       favicon-16.png, favicon-32.png, apple-touch-icon.png (180px).

Versions
  primary     Gradient tile, ink glyph (default app icon)
  ios         Full-bleed square for iOS
  dark        Ink tile, gradient glyph
  dark-white  Ink tile, white glyph
  light       White tile, ink glyph
  glyph-*     Glyph only on transparent: black, white, gradient

Brand colours: gradient #7FE9F5 > #4DF59A > #D4FF1F, ink #0A0A0A.
Do not recolour or redraw the glyph.
